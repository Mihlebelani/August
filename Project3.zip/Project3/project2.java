import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class project2 {
    public static void main(String[] args) {
        // Create the first ArrayList
        //Question 9
        ArrayList<String> list1 = new ArrayList<>();
        list1.add("Mihle");
        list1.add("Yola");
        list1.add("Mahle");

        // Create the second ArrayList
        ArrayList<String> list2 = new ArrayList<>();

        // Copy list1 to list2
        list2.addAll(list1);

        // Print the contents of list2
        System.out.println("Contents of list2: " + list2);

        //QUESTION 10

        ArrayList<String> names = new ArrayList<>();

        names.add("Mihlali");
        names.add("Neziswa");
        names.add("Mandy");
        names.add("Ezile");
        names.add("kamva");

        System.out.println("Before shuffling: " + names);

        // Shuffle the ArrayList
        Collections.shuffle(names);

        System.out.println("After shuffling: " + names);

        //QUESTION 11

        // Reverse the ArrayList
        Collections.reverse(names);

        System.out.println("After reversing: " + names);

        //QUESTION 12
        // Extract a portion of the ArrayList
        int startIndex = 2;
        int endIndex = 5;
        List<String> subList = names.subList(startIndex, endIndex);

        System.out.println("Extracted portion: " + subList);



        //QUESTION 13
        // Create the first ArrayList
        ArrayList<String> lists1 = new ArrayList<>();
        lists1.add("Red");
        lists1.add("Blue");
        lists1.add("Green");

        // Create the second ArrayList
        ArrayList<String> lists2 = new ArrayList<>();
        lists2.add("Red");
        lists2.add("Blue");
        lists2.add("Green");

        // Compare the two ArrayLists
        boolean areEqual = list1.equals(list2);

        System.out.println("Are the two ArrayLists equal? " + areEqual);

        // Add an element to the second ArrayList
        list2.add("Yellow");

        // Compare again
        areEqual = list1.equals(list2);

        System.out.println("Are the two ArrayLists equal now? " + areEqual);

        //QUESTION 14

        // Create an ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");
        colors.add("Yellow");
        colors.add("Purple");

        System.out.println("Before swapping: " + colors);

        // Swap two elements
        int index1 = 1;
        int index2 = 3;
        String temp = colors.get(index1);
        colors.set(index1, colors.get(index2));
        colors.set(index2, temp);

        System.out.println("After swapping: " + colors);

        //QUESTION 15

        // Create the first ArrayList
        ArrayList<String> list1 = new ArrayList<>();
        list1.add("Red");
        list1.add("Blue");
        list1.add("Green");

        // Create the second ArrayList
        ArrayList<String> list2 = new ArrayList<>();
        list2.add("Yellow");
        list2.add("Purple");
        list2.add("Orange");

        System.out.println("List 1: " + list1);
        System.out.println("List 2: " + list2);

        // Join the two ArrayLists
        ArrayList<String> joinedList = new ArrayList<>(list1);
        joinedList.addAll(list2);

        System.out.println("Joined List: " + joinedList);

        //QUESTION 16
        // Create the original ArrayList
        ArrayList<String> originalList = new ArrayList<>();
        originalList.add("Red");
        originalList.add("Blue");
        originalList.add("Green");

        System.out.println("Original List: " + originalList);

        // Clone the ArrayList
        ArrayList<String> clonedList = new ArrayList<>(originalList);

        System.out.println("Cloned List: " + clonedList);


    }
}
}
