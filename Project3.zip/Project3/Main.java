import javax.swing.*;
import java.util.Collections;
import java.util.Iterator;
import java.util.ListIterator;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        //QUESTION 1
        //Create an ArrayList
        ArrayList<String> colors = new ArrayList<>();

        //Adding the colors
        colors.add("Brown");
        colors.add("Pink");
        colors.add("White");
        colors.add("Black");
        colors.add("Green");

        System.out.println("Colors: " + colors);

        //QUESTION2
        ArrayList<String> color = new ArrayList<>();

        // Adding colors to the ArrayList
        color.add("Red");
        color.add("Blue");
        color.add("Green");
        color.add("Yellow");
        color.add("Purple");

        // Method 1: Enhanced For Loop
        System.out.println("Enhanced For Loop:");
        for (String colour : color) {
            System.out.println(color);
        }

        // Method 2: Index-based For Loop
        System.out.println("\nIndex-based For Loop:");
        for (int i = 0; i < color.size(); i++) {
            System.out.println(color.get(i));
        }

        // Method 3: Iterator
        System.out.println("\nIterator:");
        Iterator<String> iterator = color.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        // Method 4: ListIterator
        System.out.println("\nListIterator:");
        ListIterator<String> listIterator = color.listIterator();
        while (listIterator.hasNext()) {
            System.out.println(listIterator.next());
        }

        //QUESTION 3
s
        System.out.println("Before inserting: " + colors);

        // Insert an element at the first position
        colors.add(0, "Red");

        System.out.println("After inserting: " + colors);

        //QUESTION 4

        int index = 2;
        String element = colors.get(index);

        System.out.println("Element at index " + index + ": " + element);

        //QUESTION 5

        System.out.println("Before updating: " + colors);

        // Update an element at a specified index
        int indexx = 2;
        String newElement = "Orange";
        colors.set(indexx, newElement);

        System.out.println("After updating: " + colors);

        //QUESTION 6

        System.out.println("Before removing: " + colors);

        // Remove the third element
        colors.remove(2);

        System.out.println("After removing: " + colors);

        //QUESTION 7
        // Search for an element
        String target = "Green";
        int indexy = colors.indexOf(target);

        if (indexy != -1) {
            System.out.println("Element found at index " + index);
        } else {
            System.out.println("Element not found");
        }
        //QUESTION 8
        // Sort the ArrayList
        Collections.sort(colors);

        System.out.println("After sorting: " + colors);



    }
}